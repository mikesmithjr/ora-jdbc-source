function _returnCalendarValue(
a0,
a1
)
{
var a2=a0.returnValue;
if(a2!=(void 0))
{
var a3=a0._dateField;
if(a3==(void 0))
{
a3=_savedField1879034;
}
if(a3.value)
{
a2+=_savedTimeMS;
}
var a4=new Date(a2);
var a5=_getDateFieldFormat(a3);
var a6=a3.value;
a3.value=a5.format(a4);
a3.select();
a3.focus();
if(a3.onchange!=(void 0)&&
a3.value!=a6)
{
var a1=new Object();
a1.type="change";
if(window.event!=(void 0))
{
a1.srcElement=a1.target;
var a7=window.event;
window.event=a1;
a3.onchange(a1);
window.event=a7;
}
else
{
a1.target=a3;
a3.onchange(a1);
}
}
}
}
function _ldp(
a0,
a1,
a2,
a3,
a4
)
{
var a5=document.forms[a0][a1];
_savedTimeMS=0;
var a6;
if(a5.value!="")
{
a6=_getDateFieldFormat(a5).parse(a5.value);
if(!a6)
{
a6=new Date();
}
else
{
var a7=new Date(a6.getFullYear(),
a6.getMonth(),
a6.getDate());
_savedTimeMS=a6-a7;
}
}
else
{
a6=new Date();
}
if(!a4)
{
a4=_jspDir+"a.jsp?_t=fred&_red=cd";
}
else
{
var a8=a4.lastIndexOf('?');
var a9="";
if(a8==-1)
{
a8=a4.length;
}
else
{
a9=a4.substr(a8);
}
var a10=a4.lastIndexOf('/',a8);
var a11=a4.substring(0,a10+1);
a11+=_jspDir+"a.jsp";
a11+=a9;
a11+=(a9.length==0)
?'?'
:'&';
a11+="_t=fred";
var a12=a4.substring(a10+1,a8);
a4=a11;
a4+="&redirect="+escape(a12);
}
a4+="&value="+a6.getTime();
if(_configName.length>0)
{
a4+="&configName="+escape(_configName);
}
a4+="&loc="+_locale;
if(window["_enc"])
{
a4+="&enc="+_enc;
}
if(window["_contextURI"])
{
a4+="&contextURI="+escape(_contextURI);
}
a4+="&tzOffset="+a6.getTimezoneOffset();
if(a2!=(void 0))
{
a4+="&minValue="+a2;
}
if(a3!=(void 0))
{
a4+="&maxValue="+a3;
}
var a13=openWindow(self,
a4,
'calendar',
{width:350,height:370},
true,
void 0,
_returnCalendarValue);
a13._dateField=a5;
_savedField1879034=a5;
}
function _getDateFieldFormat(a0)
{
var a1=a0.name;
if(a1&&_dfs)
{
var a2=_dfs[a1];
if(a2)
return new SimpleDateFormat(a2);
}
return new SimpleDateFormat();
}
function _fixDFF(a0)
{
var a1=_getDateFieldFormat(a0);
if(a0.value!="")
{
var a2=_getDateFieldFormat(a0).parse(a0.value);
if(a2!=(void 0))
a0.value=a1.format(a2);
}
}
var _savedField1879034;
var _savedTimeMS;
